<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8" />
    <title>Giriş Durumu</title>
    <style>
      body.login-page.login-php {
        background-image: url('img/leopar.jpeg');
        background-size: cover;
        background-repeat: no-repeat;
        background-position: center;
        min-height: 100vh;
        font-family: "Prompt", sans-serif;
        padding-top: 100px;
        text-align: center;
      }

      .login-php .message-container {
        background-color: #f4f4f4;
        padding: 2.5rem 3rem;
        border-radius: 10px;
        box-shadow: 0 8px 20px rgba(149, 154, 145, 0.2);
        width: 800px;
        margin: 0 auto;
        display: block;
      }

      .login-php .welcome {
        background-color: rgb(212, 124, 175);
        color: #fff;
        font-weight: 700;
        font-size: 2rem;
        text-transform: uppercase;
        margin: 0 auto 1rem auto;
        padding: 1rem 2rem;
        border-radius: 10px;
        width: fit-content;
        box-shadow: 0 4px 10px rgba(128, 0, 85, 0.4);
        text-align: center;
      }

      .login-php .redirect-message {
        color: rgb(128, 0, 85);
        font-weight: 700;
        font-size: 1.2rem;
        margin-top: 1rem;
        text-align: center;
      }

      .login-php .continue-button {
        display: inline-block;
        background-color: rgb(212, 124, 175);
        color: white;
        padding: 0.75rem 2rem;
        font-weight: 700;
        font-size: 1.1rem;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        text-decoration: none;
        margin-top: 1.5rem;
        transition: background-color 0.3s ease;
      }
      .login-php .continue-button:hover {
        background-color: rgb(128, 0, 85);
      }
    </style>
</head>
<body class="login-page login-php">
    <div class="message-container">
    <?php
    $valid_user = "b241210567@sakarya.edu.tr";
    $valid_pass = "b241210567";

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $username = $_POST["username"] ?? '';
        $password = $_POST["password"] ?? '';

        if ($username === $valid_user && $password === $valid_pass) {
            echo '<h2 class="welcome">Hoşgeldiniz ' . htmlspecialchars($password) . '</h2>';
            echo '<a href="index.html" class="continue-button">Devam</a>';
        } else {
            echo '<p class="redirect-message">Giriş başarısız. Yönlendiriliyorsunuz...</p>';
            header("refresh:2;url=login.html");
            exit();
        }
    } else {
        header("Location: login.html");
        exit();
    }
    ?>
    </div>
</body>
</html>